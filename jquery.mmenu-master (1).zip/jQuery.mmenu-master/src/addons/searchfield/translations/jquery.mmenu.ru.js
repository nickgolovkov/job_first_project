(function( $ ) {

	const _PLUGIN_ = 'mmenu';

	$[ _PLUGIN_ ].i18n({
		'Search'			: 'Найти',
		'No results found.'	: 'Ничего не найдено.',
		'Search results'	: 'Результаты поиска'
	});

})( jQuery );
